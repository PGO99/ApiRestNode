require('.config/config');
const express = require('express');
const app = express();

const bodyParser = require('body-parser');
const { restart } = require('nodemon');

app.use(bodyParser.urlencoded({ extended: false }))
 
app.use(bodyParser.json())
 
app.get('/usuario', function (req, res) {
  res.json("Bienvenido");
})

app.post('/usuario', function (req, res) {
  
  let body = req.body

  if(body.nombre== undefined){

    res.status(400).json({
      ok:false,
      mensaje:'El nombre es necesario'
    });

  }else{
      res.json({
        persona:body
      });

  }
  
  res.json("Peticion post");

})

app.put('/usuario/:id', function (req, res) {

  let id = req.params.id;

  res.json({
    id
  });
});

app.delete('/usuario/:id', function (req, res) {

  let id = req.params.id;
    
    res.status(404).json({
      mensaje:"la ruta no tiene id"
    })

  res.json({
    id,
    mensaje:"Usuario Eliminado"
  });
});
 
app.listen(process.env.PORT,()=> { console.log("Servidor Escuchando:", process.env.PORT) });